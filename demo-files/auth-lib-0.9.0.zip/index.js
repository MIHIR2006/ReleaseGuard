// auth-lib 0.9.0
console.log("auth-lib 0.9.0 is running");
