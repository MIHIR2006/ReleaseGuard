# chat-app 2.0.0

Demo release for ReleaseGuard.
