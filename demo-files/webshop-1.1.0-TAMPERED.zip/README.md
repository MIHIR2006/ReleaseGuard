# webshop 1.1.0

Demo release for ReleaseGuard.
