# webshop 1.2.0

Demo release for ReleaseGuard.
